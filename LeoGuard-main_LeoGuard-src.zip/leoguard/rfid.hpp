#include <Arduino.h>

void rfid_setup();
String read_rfid();