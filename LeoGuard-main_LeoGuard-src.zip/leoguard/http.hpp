#include <Arduino.h>

void http_setup();
bool http_check_id(String uid);