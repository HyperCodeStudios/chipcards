void neopixel_setup();

void neopixel_green();
void neopixel_red();
void neopixel_white();
void neopixel_off();
